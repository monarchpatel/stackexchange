<?php
namespace Monarch\Shinesh\Model\ResourceModel;

class Shinesh extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('shinesh', 'shinesh_id');
    }
}
?>