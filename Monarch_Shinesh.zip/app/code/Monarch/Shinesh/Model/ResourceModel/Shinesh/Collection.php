<?php

namespace Monarch\Shinesh\Model\ResourceModel\Shinesh;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Monarch\Shinesh\Model\Shinesh', 'Monarch\Shinesh\Model\ResourceModel\Shinesh');
        $this->_map['fields']['page_id'] = 'main_table.page_id';
    }

}
?>